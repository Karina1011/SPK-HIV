<footer>
  <div class="container">
    <div class="row">
      <div class="col-lg-12 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.25s">
        <p class="text-center">© Copyright 2023 Sistem Pendukung Keputusan Diagnosa Penyakit HIV/AIDS 
      </div>
    </div>
  </div>
</footer>